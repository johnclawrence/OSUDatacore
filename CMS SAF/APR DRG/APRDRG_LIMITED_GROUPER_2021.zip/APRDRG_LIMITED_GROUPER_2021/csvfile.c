/*
 * (c) 3M Company 2005. Generated in 2005 as an unpublished copyrighted work.
 * This program contains confidential proprietary information of 3M. Such 
 * information may not be used or reproduced without prior written consent
 * of 3M.
 *
 * Program: csvfile.c - decode comma delimited records
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXFIELDS 160
static char *field[MAXFIELDS];
static int	has_quotes[MAXFIELDS];
static char fdata[2048];
static int    nfields;
static char   comma = ',';

void   loadFields(char *buffer);
int    getInteger(int fld);
char * getString(int fld);


char *getString(int fld)
{
	return field[fld];
}

int getInteger(int fld)
{
    char * pin;
	int n = 0;
    int minus = 0;

    pin = field[fld];
	while (*pin) {
		if (*pin >= '0' && *pin <= '9')
			n = 10 * n + (*pin - '0');
        else if (*pin == '-')
            minus = 1 - minus;
		pin += 1;
	}
	return minus ? -n : n;
}

void loadFields(char *buffer)
{
    char * p;
    char * pa;
    int i;
	int field_past_comma = 0;

	pa = fdata;
	p = buffer;
	nfields = 0;
	while (*p && *p != '\n') { /* find the fields */
		field_past_comma = 1;
		while (*p == ' ') p+= 1;  /* eliminate trailing blanks */
		if (comma == ',' && *p == '"') { /* a literal */
			has_quotes[nfields] =1;
			field[nfields++] = pa;
			for (p+=1; *p && *p != '"'; p+=1) *pa++ = *p;
			*pa++ = 0;
			if (*p == '"') { /* trailing quote */
				for (p+=1; *p == ' '; p+=1); /* bypass blanks */
				if (*p == comma) {
					p+=1; /* bypass comma */
					field_past_comma = 0;
				}
			}
		}
		else { /* not a literal */
			has_quotes[nfields] =0;
			field[nfields++] = pa;
			while (*p && *p != comma) *pa++ = *p++;
			*pa++ = 0;
			if (*p == comma) {
				p+=1; /* bypass comma */
				field_past_comma = 0;
			}
		}
		/* don't allow a input record with too many fields to mess us up */
		if (nfields == MAXFIELDS) 
			break;
	}
	/* all the rest of the fields are null */
	*pa = 0;
	/* if a null field trails the last comma */
	if (field_past_comma == 0) {
		if (nfields < MAXFIELDS)
			field[nfields++] = pa;
		else	nfields++;
	}

	/* if nfields >= MAXFIELDS then cap it */
	if (nfields > MAXFIELDS) {
		fprintf(stderr, "Too many input fields, rest are ignored for Patid %s \n", field[0]);
		nfields = MAXFIELDS;
	} else {
		for (i = nfields; i < MAXFIELDS; i++) {
			field[i] = pa;
			has_quotes[i] = 0;
		}
	}
}
