/*
 * (c) 3M Company 2015. Generated in 2015 as an unpublished copyrighted work.
 * This program contains confidential proprietary information of 3M. Such
 * information may not be used or reproduced without prior written consent of 3M.
 */

#ifndef APRLIM_H
/* #endif is at end of file */

#define APRLIM_H

typedef void *AprHANDLE;

/*
 *  AprLimOpen return codes
 */

enum {
	APRLIMD_OK          = 0,
	APRLIMD_NOT_OPEN    = 1,
	APRLIMD_BAD_DOMAIN  = 2,
	APRLIMD_BAD_APR_ROT = 3,
	APRLIMD_BAD_MAP_ROT = 4,
	APRLIMD_BAD_ERR_HND = 5
};

#ifdef __cplusplus
extern "C" {
#endif

typedef
int (*AprLimOpenFcn)(char *aprrot, char *maprot, AprHANDLE *ahandle);

typedef
void (*AprLimCloseFcn)(AprHANDLE ahandle);

typedef
int (*AprLimGroupFcn)(          /* Return is GRC or 99 if ahandle is NULL */
	AprHANDLE ahandle,
	int       codeYear,         /* Year coded                                             */
	int       codeQtr,          /* Quarter coded                                          */
	int       grprVersion,      /* Requested grouper version                              */
	int       icdCodeType,      /* ICD code type (9 = i9, 0 = i10)                        */
	int       dxCount,          /* Number of diagnosis codes                              */
	int       dxWidth,          /* Width of each diagnosis code                           */
	char      *diagnoses,       /* String of dxCount * dxWidth characters                 */
	int       prCount,          /* Number of procedure codes                              */
	int       prWidth,          /* Width of each procedure code                           */
	char      *procedures,      /* String of prCount * prWidth characters                 */
	int       ageYears,         /* Age in years                                           */
	int       ageDaysAdmit,     /* Age in days on admission (only needed if ageYears = 0) */
	int       ageDaysDisch,     /* Age in days on discharge (only needed if ageYears = 0) */
	int       sex,              /* 1 = male, 2 = female                                   */
	int       dischStatus,      /* Discharge status (UB92 or UB04)                        */
	int       birthWgtOption,   /* Birth weight option                                    */
	int       birthWeight,      /* Birth weight in grams if available                     */
	int       DMV,              /* Days on mechanical ventilator if available             */
	int*      DRG,              /* APR DRG                                                */
	int*      SOI,              /* Severity of illness                                    */
	int*      ROM               /* Risk of Mortality                                      */
);

typedef
char* (*AprLimDllVersionFcn)();

#ifdef __cplusplus
}
#endif

#endif
/* #ifndef APRLIM_H */
