/*
 * (c) 3M Company 2015. Generated in 2015 as an unpublished copyrighted work.
 * This program contains confidential proprietary information of 3M. Such
 * information may not be used or reproduced without prior written consent
 * of 3M.
 *
 * Program:  testapr.c - test harness for APR limited grouper used by AHRQ
 */

#include <stdio.h>
#include <string.h>
#include <windows.h>
#include "aprlim.h"

#define BUFFER_SIZE 2048

void        loadFields(char *input_buffer);
int         getInteger(int fld);
char        *getString(int fld);
static char input_buffer[BUFFER_SIZE];

enum {ARG_PROG, ARG_DLL, ARG_CURRROT, ARG_MAPROT, ARG_INFILE, ARG_LIMIT, ARG_COUNT};

enum {
	FLD_CaseID       =  0,
	FLD_GrprFamily   =  1,
	FLD_GrprVersion  =  2,
	FLD_IcdVer       =  3,
	FLD_AdmitDx      =  4,
	FLD_NumDx        =  5,
	FLD_DxWidth      =  6,
	FLD_Dx           =  7,

	FLD_NumPr        =  9,
	FLD_PrWidth      = 10,
	FLD_Procs        = 11,
	FLD_AgeYears     = 12,
	FLD_Sex          = 13,
	FLD_Dstat        = 14,
	FLD_AgeDaysAdmit = 15,
	FLD_AgeDaysDisch = 16,
	FLD_BwtOption    = 17,
	FLD_Bwt          = 18,
	FLD_DMV          = 19,
	FLD_CodeYear     = 20,
	FLD_CodeQtr      = 21,

	FLD_GRC          = 25,

	FLD_DRG          = 27,
	FLD_SOI          = 28,
	FLD_ROM          = 29
};


int main(int argc, char **argv)
{
	AprLimOpenFcn       AprLimOpen;
	AprLimCloseFcn      AprLimClose;
	AprLimGroupFcn      AprLimGroup;
	AprLimDllVersionFcn AprLimDllVersion;
	AprHANDLE           apr;
	HMODULE             hDLL;

	int  rc;
	int  limit;
	int  process_count  = 0;
	int  mismatch_count = 0;
	int  family, version, numdx, dxwidth, numpr, prwidth, ageyrs;
	int  sex, dstat, ageda, agedd, bwo, bwgt, dmv;
	int  codeyr, codeqtr;
	int  icd_type;
	int  grc, drg, soi, rom;
	int  egrc, edrg, esoi, erom;

	char *dll_version;
	char *caseid;
	char *diagnoses;
	char *procedures;
	char *p;

	FILE *infile;

	if (argc < ARG_COUNT) {
		fputs("Usage:  testapr DLL apr_ROT apr_ROT map_ROT input_file limit\n", stderr);
		return 0;
	}

	p    = argv[ARG_DLL];
	hDLL = LoadLibraryA(p);
	if (!hDLL) {
		fprintf(stderr, "Cannot open library %s (%d)\n", p, GetLastError());
		return 1;
	}

	AprLimOpen = (AprLimOpenFcn)GetProcAddress(hDLL, "AprLimOpen");
	if (!AprLimOpen) {
		FreeLibrary(hDLL);
		fprintf(stderr, "Cannot find AprLimOpen (%d)\n", GetLastError());
		return 1;
	}

	AprLimClose = (AprLimCloseFcn)GetProcAddress(hDLL, "AprLimClose");
	if (!AprLimClose) {
		FreeLibrary(hDLL);
		fprintf(stderr, "Cannot find AprLimClose (%d)\n", GetLastError());
		return 1;
	}

	AprLimGroup = (AprLimGroupFcn)GetProcAddress(hDLL, "AprLimGroup");
	if (!AprLimGroup) {
		FreeLibrary(hDLL);
		fprintf(stderr, "Cannot find AprLimGroup (%d)\n", GetLastError());
		return 1;
	}

	AprLimDllVersion = (AprLimDllVersionFcn)GetProcAddress(hDLL, "AprLimDllVersion");
	if (!AprLimDllVersion) {
		FreeLibrary(hDLL);
		fprintf(stderr, "Cannot find AprLimDllVersion (%d)\n", GetLastError());
		return 1;
	}

	dll_version = AprLimDllVersion();
	fprintf(stderr, "DLL Version:  %s\n", dll_version);

	rc = AprLimOpen(argv[ARG_CURRROT], argv[ARG_MAPROT], &apr);
	if (rc) {
		fprintf(stderr, "Error %d opening ROTs:  apr_ROT=%s map_ROT=%s\n", rc, argv[ARG_CURRROT], argv[ARG_MAPROT]);
		return 1;
	}

	p = argv[ARG_INFILE];

	if (fopen_s(&infile, p, "r") != 0) {
		fprintf(stderr, "Cannot open %s\n", p);
		return 1;
	}

	limit = atoi(argv[ARG_LIMIT]);

	while (fgets(input_buffer, sizeof(input_buffer), infile)) {
		if (limit && process_count >= limit)
			break;

		for (p = input_buffer + strlen(input_buffer) - 1; p >= input_buffer; p -= 1) {
			if (*p > ' ')
				break;

			*p = 0;
		}

		process_count += 1;

		loadFields(input_buffer);

		caseid     = getString(FLD_CaseID);

		family     = getInteger(FLD_GrprFamily);
		version    = getInteger(FLD_GrprVersion);
		icd_type   = getInteger(FLD_IcdVer);
		numdx      = getInteger(FLD_NumDx);
		dxwidth    = getInteger(FLD_DxWidth);

		diagnoses  = getString(FLD_Dx);

		numpr      = getInteger(FLD_NumPr);
		prwidth    = getInteger(FLD_PrWidth);

		procedures = getString(FLD_Procs);

		ageyrs     = getInteger(FLD_AgeYears);
		sex        = getInteger(FLD_Sex);
		dstat      = getInteger(FLD_Dstat);
		ageda      = getInteger(FLD_AgeDaysAdmit);
		agedd      = getInteger(FLD_AgeDaysDisch);
		bwo        = getInteger(FLD_BwtOption);
		bwgt       = getInteger(FLD_Bwt);
		dmv        = getInteger(FLD_DMV);
		codeyr     = getInteger(FLD_CodeYear);
		codeqtr    = getInteger(FLD_CodeQtr);
		egrc       = getInteger(FLD_GRC);
		edrg       = getInteger(FLD_DRG);
		esoi       = getInteger(FLD_SOI);
		erom       = getInteger(FLD_ROM);

		//The grouper gets always called with grouper family 4 in AprLimGroup. 
		//Check here to just verify the unit test record field.
		if (family != 4) {
			grc = 51;
			drg =  0;
			soi =  0;
			rom =  0;
		} else {
			grc = AprLimGroup(apr,codeyr,codeqtr,version,icd_type,numdx,dxwidth,diagnoses,numpr,prwidth,procedures,ageyrs,ageda,agedd,sex,dstat,bwo,bwgt,dmv,&drg,&soi,&rom);
		}

		if (egrc != grc)
			printf("%s (%d/%d) GRC: %d expected, %d actual\n", caseid, codeyr, codeqtr, egrc, grc);

		if (edrg != drg)
			printf("%s (%d/%d) DRG: %d expected, %d actual\n", caseid, codeyr, codeqtr, edrg, drg);

		if (esoi != soi)
			printf("%s (%d/%d) SOI: %d expected, %d actual\n", caseid, codeyr, codeqtr, esoi, soi);

		if (erom != rom)
			printf("%s (%d/%d) ROM: %d expected, %d actual\n", caseid, codeyr, codeqtr, erom, rom);

		if (egrc != grc || edrg != drg || esoi != soi || erom != rom)
			mismatch_count += 1;
	}

	fprintf(stderr, "%7d records processed\n",       process_count);
	fprintf(stderr, "%7d records with mismatches\n", mismatch_count);

	fclose(infile);
	AprLimClose(apr);
	FreeLibrary(hDLL);

	return 0;
}
